/**
* Created on Apr 17, 2012 4:04:44 PM
*/
package com.sogou.gamemall.activity.interfaces;

import com.sogou.gamemall.activity.views.BaseViewSize;

import android.widget.LinearLayout;


/**
 * <p>Created on Apr 17, 2012 4:04:44 PM</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore.activities.view</p>
 * <p>File: ILeview.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:qixl1@lenovo.com">漆兴隆(Seven Qi)</a>
 * @version 1.0
 * @see
 */

public abstract interface ISoView {

    BaseViewSize getBaseViewSize();

    BaseViewType getViewType();

    void setLayoutParams(LinearLayout.LayoutParams params);

    enum BaseViewType {
        CONTAINER(1, "container"), BUTTON(2, "lebutton");

        int mType;
        String mDetails;

        BaseViewType(int type, String details) {
            mType = type;
            mDetails = details;
        }

    };

}
