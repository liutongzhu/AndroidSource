/**
* Created on Apr 17, 2012 6:34:37 PM
*/
package com.sogou.gamemall.activity.views;

import com.sogou.gamemall.R;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

/**
 * <p>Created on Apr 17, 2012 6:34:37 PM</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore.activities.view</p>
 * <p>File: BaseView.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:qixl1@lenovo.com">漆兴隆(Seven Qi)</a>
 * @version 1.0
 * @see
 */

public class BaseViewSize {
	public static float density = 0f;
    public BaseViewSize(Context context, AttributeSet attrs) {
        super();
        TypedArray typeArray = context.obtainStyledAttributes(attrs, R.styleable.SoStyle);
        min_width = typeArray.getInt(R.styleable.SoStyle_min_width, 0);
        min_width = dip2px(density, min_width);
        per_width = typeArray.getInt(R.styleable.SoStyle_per_width, 0);
        per_width = dip2px(density, per_width);
        max_width = typeArray.getInt(R.styleable.SoStyle_max_width, 0);
        max_width = dip2px(density, max_width);
        min_height = typeArray.getInt(R.styleable.SoStyle_min_height, 0);
        min_height = dip2px(density, min_height);
        per_height = typeArray.getInt(R.styleable.SoStyle_per_height, 0);
        per_height = dip2px(density, per_height);
        max_height = typeArray.getInt(R.styleable.SoStyle_max_height, 0);
        max_height = dip2px(density, max_height);
        weight = typeArray.getFloat(R.styleable.SoStyle_weight, 0.0f);
        typeArray.recycle();
    }

    public int min_width;
    public int per_width;
    public int max_width;
    public int min_height;
    public int per_height;
    public int max_height;
    public int current_width;
    public int current_height;
    public float weight = 0.0f;

    public static int dip2px(final float density, final float dpValue) {
        //final float scale = context.getResources().getDisplayMetrics().density; 
        return (int) (dpValue * density + 0.5f);
    }
}
