/**
* Created on Apr 11, 2012 11:00:44 AM
*/
package com.sogou.gamemall.activity.fragments;

import com.sogou.gamemall.activity.interfaces.IDoingBackground;
import com.sogou.gamemall.activity.interfaces.ISoView;
import com.sogou.gamemall.activity.views.BaseViewSize;
import com.sogou.gamemall.activity.views.SoButton;
import com.sogou.gamemall.activity.views.SoLinearLayout;
import com.sogou.gamemall.utils.LogHelper;

import android.support.v4.app.Fragment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

/**
 * <p>Created on Apr 11, 2012 11:00:44 AM</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore.activities.base</p>
 * <p>File: BaseFragment.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:qixl1@lenovo.com">漆兴隆(Seven Qi)</a>
 * @version 1.0
 * @see
 */

public abstract class BaseFragment extends Fragment implements IDoingBackground, OnClickListener {

    public static final String tag = " BaseFragment ";
    public static final int MIN = 1;
    public static final int PER = 2;
    public static final int MAX = 3;
    public static final int SCALE = 4;

    /**
     * 
     * @param isError
     * @param view
     */
    public final void showContent(boolean isError, LinearLayout view) {
        checkContent(isError, view);
    };

    public void checkContent(boolean isError, LinearLayout view) {

        if (isError) {
            view.getChildAt(0).setVisibility(View.VISIBLE);
            for (int i = 1; i < view.getChildCount(); i++) {
                view.getChildAt(i).setVisibility(View.GONE);
            }
        } else {
            view.getChildAt(0).setVisibility(View.GONE);
            for (int i = 1; i < view.getChildCount(); i++) {
                view.getChildAt(i).setVisibility(View.VISIBLE);
            }
        }
    }

    public boolean setCurrentParams(SoLinearLayout parentView, int parentWidth, int parentHeight) {
        //LogHelper.i("zz", "setCurrentParams");
//        long start = System.currentTimeMillis();

        int childCount = parentView.getChildCount();
        int sub_min_width = 0;
        int sub_per_width = 0;
        int sub_max_width = 0;
        int sub_min_height = 0;
        int sub_per_height = 0;
        int sub_max_height = 0;
        //横向排列，第一次循环，计算所有的子节点的BaseViewSize
        if (parentView.getOrientation() == LinearLayout.HORIZONTAL) {
            for (int i = 0; i < childCount; i++) {
                BaseViewSize baseViewSize = ((ISoView) parentView.getChildAt(i)).getBaseViewSize();
                sub_min_width = sub_min_width + baseViewSize.min_width;
                sub_per_width = sub_per_width + baseViewSize.per_width;
                sub_max_width = sub_max_width + baseViewSize.max_width;
                sub_min_height = sub_min_height + baseViewSize.min_height;
                sub_per_height = sub_per_height + baseViewSize.per_height;
                sub_max_height = sub_max_height + baseViewSize.max_height;
            }
        } else {
            BaseViewSize baseViewSize = parentView.getBaseViewSize();
            sub_min_width = baseViewSize.min_width;
            sub_per_width = baseViewSize.per_width;
            sub_max_width = baseViewSize.max_width;
            sub_min_height = baseViewSize.min_height;
            sub_per_height = baseViewSize.per_height;
            sub_max_height = baseViewSize.max_height;
        }

        //无法满足最小的宽度需求
        if (sub_min_width > parentWidth) {
            return false;
        } else if (sub_min_width == parentWidth) {
            //以最小宽度显示
            setViewParams(parentView, parentWidth, MIN);
        } else if (sub_per_width == parentWidth) {
            //已最合适宽度显示
            setViewParams(parentView, parentWidth, MAX);
        } else if (sub_max_width == parentWidth) {
            //已最大宽度显示
            setViewParams(parentView, parentWidth, PER);
        } else {
            //按比例区显示
            setViewParams(parentView, parentWidth, SCALE);
        }
//        long end = System.currentTimeMillis();
        //LogHelper.i("zz", "spend time : " + (end - start));
        return true;
    }

    //第二次循环，对所有控件开始布局
    private void setViewParams(SoLinearLayout parentView, int parentWidth, int scale) {
        int childCount = parentView.getChildCount();

        if (scale == SCALE) {
            //计算没有配置appstore:weight的元素宽度
            int sub_no_weight_width = 0;
            for (int i = 0; i < childCount; i++) {
                ISoView leView = null;
                try {
                    leView = (ISoView) parentView.getChildAt(i);
                } catch (Exception e) {
                    LogHelper.w("AppStore", "This view can't be cast to LeView!");
                    return;
                }
                if (leView.getBaseViewSize().weight < 0.001f) {
                    sub_no_weight_width = sub_no_weight_width + leView.getBaseViewSize().per_width;
                }
            }
            int sub_current_width = parentWidth - sub_no_weight_width;
            for (int i = 0; i < childCount; i++) {
                ISoView leView = (ISoView) parentView.getChildAt(i);
                int height = leView.getBaseViewSize().per_height;
                float weight = leView.getBaseViewSize().weight;
                //LogHelper.i("zz", "weight: "+weight);
                int width = (int) (sub_current_width * weight);
                //LogHelper.i("zz", "width: "+width);
                setParams(parentView, width, height, i, scale);
            }

        } else {
            for (int i = 0; i < childCount; i++) {
                ISoView leView = null;
                try {
                    leView = (ISoView) parentView.getChildAt(i);
                } catch (Exception e) {
                    LogHelper.w("AppStore", "This view can't be cast to LeView!");
                    return;
                }

                int height = leView.getBaseViewSize().per_height;
                if (scale == MIN) {
                    setParams(parentView, leView.getBaseViewSize().min_width, height, i, scale);
                } else if (scale == PER) {
                    setParams(parentView, leView.getBaseViewSize().per_width, height, i, scale);
                } else if (scale == MAX) {
                    setParams(parentView, leView.getBaseViewSize().max_width, height, i, scale);
                }
            }
        }
    }

    //将LinearLayout.LayoutParams设置在每个控件上
    private void setParams(SoLinearLayout parentView, int width, int Height, int position, int scale) {
        LinearLayout.LayoutParams params = null;
        ISoView leView = null;
        try {
            leView = (ISoView) parentView.getChildAt(position);
        } catch (Exception e) {
            LogHelper.w("AppStore", "This view can't be cast to LeView!");
            return;
        }

        if (leView.getViewType() == ISoView.BaseViewType.CONTAINER) {
            SoLinearLayout leLinearLayout = (SoLinearLayout) leView;
            params = new LinearLayout.LayoutParams(width, Height);
            leLinearLayout.setLayoutParams(params);
            setViewParams(leLinearLayout, width, scale);
            setCurrentParams(leLinearLayout, width, Height);
        } else if (leView.getViewType() == ISoView.BaseViewType.BUTTON) {
            SoButton leButton = (SoButton) leView;
            params = new LinearLayout.LayoutParams(width, Height);
            leButton.setLayoutParams(params);
        }
        leView.setLayoutParams(params);
    }

}
