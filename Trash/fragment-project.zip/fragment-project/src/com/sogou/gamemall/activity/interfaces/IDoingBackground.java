/**
* Created on Apr 13, 2012 2:18:08 PM
*/
package com.sogou.gamemall.activity.interfaces;

/**
 * <p>Created on Apr 13, 2012 2:18:08 PM</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore.activities.base</p>
 * <p>File: DoingBackground.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:qixl1@lenovo.com">漆兴隆(Seven Qi)</a>
 * @version 1.0
 * @see
 */

public interface IDoingBackground {
    void runAsyncTask();
}
