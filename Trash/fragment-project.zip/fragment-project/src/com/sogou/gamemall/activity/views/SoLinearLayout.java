/**
* Created on Apr 16, 2012 10:23:11 AM
*/
package com.sogou.gamemall.activity.views;

import com.sogou.gamemall.activity.interfaces.ISoView;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.RemoteViews.RemoteView;

/**
 * 
 * <p>Created on Apr 17, 2012 1:54:34 PM</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore.activities.view</p>
 * <p>File: LeLinearLayout.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:qixl1@lenovo.com">漆兴隆(Seven Qi)</a>
 * @version 1.0
 * @see
 */

@RemoteView
public class SoLinearLayout extends LinearLayout implements ISoView {
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // TODO Auto-generated method stub
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public BaseViewSize baseViewSize;

    /**
     * @param context
     */
    public SoLinearLayout(Context context) {
        super(context);
    }

    public SoLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        baseViewSize = new BaseViewSize(context, attrs);
    }

    @Override
    public BaseViewSize getBaseViewSize() {
        return baseViewSize;
    }

    @Override
    public BaseViewType getViewType() {
        return BaseViewType.CONTAINER;
    }

    @Override
    public void setLayoutParams(LayoutParams params) {
        super.setLayoutParams(params);
    }

}
