/**
* Created on Apr 16, 2012 10:23:11 AM
*/
package com.sogou.gamemall.activity.views;

import com.sogou.gamemall.activity.interfaces.ISoView;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioButton;
import android.widget.RemoteViews.RemoteView;

/**
 * <p>Created on Apr 16, 2012 10:23:11 AM</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore.activities.view</p>
 * <p>File: LeButton.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:qixl1@lenovo.com">漆兴隆(Seven Qi)</a>
 * @version 1.0
 * @see
 */

@RemoteView
public class SoButton extends RadioButton implements ISoView {

    public BaseViewSize baseViewSize;

    /**
     * @param context
     */
    public SoButton(Context context) {
        super(context);
    }

    public SoButton(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
        baseViewSize = new BaseViewSize(context, attrs);
    }

    public SoButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public BaseViewSize getBaseViewSize() {
        return baseViewSize;
    }

    @Override
    public BaseViewType getViewType() {
        return BaseViewType.BUTTON;
    }

    /* (non-Javadoc)
     * @see com.lenovo.leos.appstore.activities.interfaces.ILeView#setLayoutParams(android.widget.LinearLayout.LayoutParams)
     */
    @Override
    public void setLayoutParams(LayoutParams params) {
        super.setLayoutParams(params);
    }

}
