package com.sogou.gamemall.dataprovider;

public class BuildConfig {
	public final static boolean DEBUG = true;
}
