package com.sogou.gamemall.dataprovider.entity;

import java.io.Serializable;

/**
 * 
 * <p>Project: Lenovo ideaStore</p>
 * <p>Module: AppStore5</p>
 * <p>Package: com.lenovo.leos.appstore5.db.entity</p>
 * <p>File: BaseEntity.java</p>
 * <p>Description:Base Entity </p>
 * <p>Copyright: Copyright (c) 2011. All rights reserved.</p>
 * <p>Company: www.lenovo.com</p>
 * @author <a href="mailto:zhaoml1@lenovo.com">赵明亮(Matt zhao)</a>
 * @version 1.0
 * @see
 */
public class BaseEntity implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 736956996153893533L;
    
      enum CatRDType{
            
            APP(1,"app"),
            CATEGORY(2,"category"),
            AD(3,"ad");
            
            int mType;
            String mDetails;
            
            CatRDType(int type,String details){
                    mType = type;
                    mDetails = details;
            }
            
        };
}
