package com.sogou.gamemall.dataprovider.entity;

import java.io.Serializable;

public class Application extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    private String averageStar;
    private String developerId;
    private String developerName;
    private String discount;
    private String fState;
    private String hState;
    private String iconAddr;
    private String ispay;
    private String lState;
    private String name;
    private String packageName;
    private String price;
    private String publishDate;
    private String size;
    private String vState;
    private String version;
    private String versioncode;

    public Application() {
        averageStar = "";
        developerId = "";
        developerName = "";
        discount = "";
        fState = "";
        hState = "";
        iconAddr = "";
        ispay = "";
        lState = "";
        name = "";
        packageName = "";
        price = "";
        publishDate = "";
        size = "";
        vState = "";
        version = "";
        versioncode = "";
    }

    public String getAverageStar() {
        return averageStar;
    }

    public void setAverageStar(String averageStar) {
        this.averageStar = averageStar;
    }

    public String getDeveloperId() {
        return developerId;
    }

    public void setDeveloperId(String developerId) {
        this.developerId = developerId;
    }

    public String getDeveloperName() {
        return developerName;
    }

    public void setDeveloperName(String developerName) {
        this.developerName = developerName;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getfState() {
        return fState;
    }

    public void setfState(String fState) {
        this.fState = fState;
    }

    public String gethState() {
        return hState;
    }

    public void sethState(String hState) {
        this.hState = hState;
    }

    public String getIconAddr() {
        return iconAddr;
    }

    public void setIconAddr(String iconAddr) {
        this.iconAddr = iconAddr;
    }

    public String getIspay() {
        return ispay;
    }

    public void setIspay(String ispay) {
        this.ispay = ispay;
    }

    public String getlState() {
        return lState;
    }

    public void setlState(String lState) {
        this.lState = lState;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getvState() {
        return vState;
    }

    public void setvState(String vState) {
        this.vState = vState;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getVersioncode() {
        return versioncode;
    }

    public void setVersioncode(String versioncode) {
        this.versioncode = versioncode;
    }

}
